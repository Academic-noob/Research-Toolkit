#!/bin/bash
#SBATCH --job-name=SnB_PBE
#SBATCH --partition=cpu2_q
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=40
#SBATCH --output=slurm-%j.out
#SBATCH --error=slurm-%j.err

set -euo pipefail
cd "${SLURM_SUBMIT_DIR}"

export OMP_NUM_THREADS=1
VASP_EXE="/opt/ohpc/pub/apps/vasp5.4.4/bin/vasp_std"
mpirun -np "${SLURM_NTASKS}" "${VASP_EXE}"
